package com.cg.appl.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity(name="employee")

@Table(name="EMP")

public class Emp implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private int empNo;
	private String empNm;
	private Float empSal;
	
	@Id
	@Column(name="EMPNO")
	public int getEmpNo() {		//empNo Property Names
		return empNo;
	}
	
	@Column(name="ENAME")
	public String getEmpNm() {	//empNm
		return empNm;
	}
	@Column(name="SAL")
	public float getEmpSal() {	//empSal
		return empSal;
	}
	public void setEmpNo(int empNo) {
		this.empNo = empNo;
	}
	public void setEmpNm(String empNm) {
		this.empNm = empNm;
	}
	public void setEmpSal(Float empSal) {
		this.empSal = empSal;
	}
	@Override
	public String toString() {
		return "Emp [empNo=" + empNo + ", empNm=" + empNm + ", empSal="
				+ empSal + "]";
	}
}

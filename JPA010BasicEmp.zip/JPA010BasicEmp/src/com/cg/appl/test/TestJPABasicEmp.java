package com.cg.appl.test;


import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.cg.appl.entities.Emp;

public class TestJPABasicEmp {

	public static void main(String[] args) {

		//1.Create Entity Manager Factory (Make datasoucre,connection pool,cache-2 ready)
		
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA-PU");
		
		//2.Create Entity Manager(Makes Cache1 ready,Dialect)
		
		EntityManager manager=factory.createEntityManager();
		
		/*
		//3.Get a Record.
		Emp emp=manager.find(Emp.class,7499);
		System.out.println(emp);*/
		
		
		Query qry=manager.createQuery("select e from employee as e where empSal >= 4000");//use property name and entity name not a column name of table
		List<Emp> empList=qry.getResultList();
		
		for(Emp emp : empList)
			System.out.println(emp);
		
	
		//4.Close the Resources.
		manager.clear();
		factory.close();
	}	

}

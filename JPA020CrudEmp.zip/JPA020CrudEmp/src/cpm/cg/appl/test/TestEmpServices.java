package cpm.cg.appl.test;

import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.EmpException;
import com.cg.appl.services.EmpServices;
import com.cg.appl.services.EmpServicesImpl;

public class TestEmpServices {

	public static void main(String[] args) throws EmpException {
		
		try {
			
			EmpServices services=new EmpServicesImpl();
			//Emp emp=services.getEmpDetails(7499);
			//System.out.println(emp);	
			
			/*for(Emp emp:services.getEmpsForComm())
				System.out.println(emp);*/
			
			/*Emp emp=new Emp();
			emp.setEmpNo(1111);
			emp.setEmpNm("Vivek");
			emp.setEmpSal(20000f);
			services.admitNewEmp(emp);
			System.out.println(services.getEmpDetails(1111));*/
			
			
		//services.updateName(7499,"VVVVV");
			
		/*	Emp emp=new Emp();
			emp.setEmpNo(1111);
			emp.setEmpNm("Abinav");
			emp.setEmpSal(9000F);
			services.updateEmp(emp);*/
			
			
			/*services.deleteEmp(1111);
			System.out.println(services.getEmpDetails(1111));*/
		} catch (EmpException e) {
			e.printStackTrace();
			//throw new EmpException("Wrong Emp Number");
		}	
	}
}

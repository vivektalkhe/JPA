package cpm.cg.appl.test;

import java.util.List;

import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.EmpException;
import com.cg.appl.services.EmpServices;
import com.cg.appl.services.EmpServicesImpl;

public class TestEmpQueries {


	public static void main(String[] args) {
		try {
			EmpServices services=new EmpServicesImpl();
			//List<Emp> empList=services.getEmpsOnSal(2000, 4000);
			
			/*for(Emp empList:services.getEmpList())
			{
				System.out.println(empList);
			}
			*/
			
			/*Emp emp=new Emp();
			emp.setEmpNm("Vide");
			emp.setEmpSal(50000f);
			emp=services.admitNewEmp(emp);
			System.out.println(emp);*/
			
			
			List<Emp> empList=services.getEmpsForComm();
			
			for(Emp emp:empList)
			{
				System.out.println(emp);
			}
			
			
			
		} catch (EmpException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		

	}

}

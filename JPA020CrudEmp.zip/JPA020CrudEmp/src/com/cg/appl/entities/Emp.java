package com.cg.appl.entities;


import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity(name="employee")

@Table(name="EMP")

@NamedQueries({
	@NamedQuery(name="qryEmpsOnSal",query="select e from employee as e where empSal between :from and :to"),
	@NamedQuery(name="qryAllEmps",query="select e from employee e"),
	@NamedQuery(name="qryEmpsComm",query="select e from employee e")
				
})
@SequenceGenerator(name="emp_generate",sequenceName="EMP_SEQ",allocationSize=1,initialValue=1)
public class Emp implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private int empNo;
	private String empNm;
	private Float empSal;
	private Float commission;
	private Float totalSalary;
	
	@Id
	@Column(name="EMPNO")
	@GeneratedValue(generator="emp_generate",strategy=GenerationType.SEQUENCE)
	public int getEmpNo() {		//empNo Property Names
		return empNo;
	}
	
	@Column(name="ENAME")
	public String getEmpNm() {	//empNm
		return empNm;
	}
	@Column(name="SAL")
	public float getEmpSal() {	//empSal
		return empSal;
	}
	
	
	@Column(name="COMM")
	public Float getCommission() {
		return commission;
	}


	public void setEmpNo(int empNo) {
		this.empNo = empNo;
	}
	public void setEmpNm(String empNm) {
		this.empNm = empNm;
	}
	public void setEmpSal(Float empSal) {
		this.empSal = empSal;
	}
	
	public void setCommission(Float commission) {
		this.commission = commission;
	}

	
	//@Column(name="SAL+COMM")
	@Transient
	public Float getTotalSalary() {
		return getEmpSal()+(getCommission()==null ? 0 :getCommission());
		
	}

	/*public void setTotalSalary(Float totalSalary) {
		this.totalSalary = totalSalary;
	}
*/
	@Override
	public String toString() {
		return "Emp [empNo=" + empNo + ", empNm=" + empNm + ", empSal="
				+ empSal + ", commission=" + commission + ", totalSalary="
				+ getTotalSalary() + "]";
	}
}
